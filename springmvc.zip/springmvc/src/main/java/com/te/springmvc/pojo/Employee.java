package com.te.springmvc.pojo;

import lombok.Data;

@Data
public class Employee {
	private String user;
	private String pwd;
}
